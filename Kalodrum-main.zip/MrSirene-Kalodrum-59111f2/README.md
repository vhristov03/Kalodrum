# Kalodrum
5 spreltaci
# 
Kato cqlo tva e
